#!/bin/sh
cd `dirname "$0"`
sudo killall nginx
sudo ./nginx
IP=`LC_ALL=C ifconfig  | grep -E 'inet.[0-9]' | grep -v '127.0.0.1' | awk '{ print $2}'`
open "http://$IP/"
