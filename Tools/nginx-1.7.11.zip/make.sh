#!/bin/sh
cd `dirname "$0"`
./configure --prefix=. --without-http_rewrite_module --with-http_dav_module --add-module=./nginx-dav-ext-module
make
